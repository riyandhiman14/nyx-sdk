"""Nyx — stealth browser automation for Python, powered by Aegis."""

from nyx.client import Nyx
from nyx.browser import Browser, Snapshot
from nyx.page import Page
from nyx.locator import Locator
from nyx.response import Response
from nyx.errors import (
    NyxError, NyxTimeout, NyxConnectionError, NyxNotFound,
    NyxInstallError, NyxLaunchError, NyxBrowserCrashed,
)

__version__ = "0.2.0b1"
__all__ = [
    "Nyx", "Browser", "Snapshot", "Page", "Locator", "Response",
    "NyxError", "NyxTimeout", "NyxConnectionError", "NyxNotFound",
    "NyxInstallError", "NyxLaunchError", "NyxBrowserCrashed",
]
